
<?php  include 'controller/mainClassController.php';  ?>

<?php  include 'controller/authController.php';  ?>

<?php  include 'include/header.php';  ?>

<?php  include 'views/add_course.php';  ?>

<?php  include 'include/footer.php';  ?>

<?php  include 'xhr/add_course.php';  ?>
