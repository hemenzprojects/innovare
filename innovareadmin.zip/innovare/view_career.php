
<?php  include 'controller/mainClassController.php';  ?>

<?php  include 'controller/authController.php';  ?>

<?php  //include 'controller/courseController.php';  ?>

<?php  include 'include/header.php';  ?>

<?php  include 'views/view_career.php';  ?>

<?php  include 'include/footer.php';  ?>

