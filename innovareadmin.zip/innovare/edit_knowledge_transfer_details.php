
<?php  include 'controller/mainClassController.php';  ?>

<?php  include 'controller/authController.php';  ?>

<?php  include 'controller/knowledgeTransferController.php';  ?>

<?php  include 'include/header.php';  ?>

<?php  include 'views/edit_knowledge_transfer_details.php';  ?>

<?php  include 'include/footer.php';  ?>

<?php  include 'xhr/edit_knowledge_transfer.php';  ?>
