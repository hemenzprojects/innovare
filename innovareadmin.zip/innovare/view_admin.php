
<?php  include 'controller/mainClassController.php';  ?>

<?php  include 'controller/authController.php';  ?>

<?php  include 'controller/adminController.php';  ?>

<?php  include 'include/header.php';  ?>

<?php // include 'include/partials/toolbar_set.php';  ?>


<?php  include 'views/view_admin.php';  ?>


<?php  include 'include/footer.php';  ?>

