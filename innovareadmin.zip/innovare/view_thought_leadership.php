
<?php  include 'controller/mainClassController.php';  ?>

<?php  include 'controller/authController.php';  ?>

<?php  include 'controller/thoughtLeadershipController.php';  ?>

<?php  include 'include/header.php';  ?>

<?php  include 'views/view_thought_leadership.php';  ?>

<?php  include 'include/footer.php';  ?>

