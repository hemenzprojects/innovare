
<?php  include 'controller/mainClassController.php';  ?>

<?php  include 'controller/authController.php';  ?>

<?php  include 'controller/caseStudyCatController.php';  ?>

<?php  include 'include/header.php';  ?>

<?php  include 'views/case_study_categories.php';  ?>

<?php  include 'include/footer.php';  ?>

<?php  include 'xhr/case_study_category.php';  ?>
