/*
*
* ==================================================
* READ ME - upload instructions
* ==================================================
*
*/


edit innovare.propertise
----------------------------
1. change database username, passsword and db_name to configuration used in setting up databas

2. locate the  innovare.propertise

3. find line 7 - 10, replace with 
        -- https://localhost/innovare_web/ --
   with 
        -- https://website url/ --

4. check file/folder permissions in static folder
