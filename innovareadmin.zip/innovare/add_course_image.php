
<?php  include 'controller/mainClassController.php';  ?>

<?php  include 'controller/authController.php';  ?>

<?php  include 'controller/courseImageController.php';  ?>

<?php  include 'include/header.php';  ?>

<?php  include 'views/add_course_image.php';  ?>

<?php  include 'include/footer.php';  ?>

<?php  include 'xhr/upload_course_doc.php';  ?>
