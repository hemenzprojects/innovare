
<?php  include 'controller/mainClassController.php';  ?>

<?php  include 'controller/authController.php';  ?>

<?php  include 'controller/consultingController.php';  ?>

<?php  include 'include/header.php';  ?>

<?php  include 'views/view_consulting_details.php';  ?>

<?php  include 'include/footer.php';  ?>

