
<?php  include 'controller/mainClassController.php';  ?>

<?php  include 'controller/authController.php';  ?>

<?php  include 'controller/thoughtLeadershipController.php';  ?>

<?php  include 'include/header.php';  ?>

<?php  include 'views/view_thought_leadership_videos.php';  ?>

<?php  include 'include/footer.php';  ?>

<?php  include 'xhr/add_thought_leardership_video.php';  ?>
