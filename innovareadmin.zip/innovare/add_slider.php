
<?php  include 'controller/mainClassController.php';  ?>

<?php  include 'controller/authController.php';  ?>

<?php  include 'controller/sliderController.php';  ?>

<?php  include 'include/header.php';  ?>

<?php  include 'views/add_slider.php';  ?>

<?php  include 'include/footer.php';  ?>

<?php  include 'xhr/add_slider.php';  ?>
