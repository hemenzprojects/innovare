
<?php  include 'controller/mainClassController.php';  ?>

<?php  include 'controller/authController.php';  ?>

<?php  include 'controller/caseStudyController.php';  ?>

<?php  include 'include/header.php';  ?>

<?php  include 'views/view_case_study_details.php';  ?>

<?php  include 'include/footer.php';  ?>

