
<?php  include 'controller/mainClassController.php';  ?>

<?php  include 'controller/authController.php';  ?>

<?php  include 'controller/teamController.php';  ?>

<?php  include 'include/header.php';  ?>

<?php  include 'views/edit_team_details.php';  ?>

<?php  include 'include/footer.php';  ?>

<?php  include 'xhr/edit_team.php';  ?>
