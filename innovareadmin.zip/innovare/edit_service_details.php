
<?php  include 'controller/mainClassController.php';  ?>

<?php  include 'controller/authController.php';  ?>

<?php  include 'controller/servicesController.php';  ?>

<?php  include 'include/header.php';  ?>

<?php  include 'views/edit_service_details.php';  ?>

<?php  include 'include/footer.php';  ?>

<?php  include 'xhr/edit_service.php';  ?>
