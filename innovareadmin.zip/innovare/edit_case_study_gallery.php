
<?php  include 'controller/mainClassController.php';  ?>

<?php  include 'controller/authController.php';  ?>

<?php  include 'controller/caseStudyController.php';  ?>

<?php  include 'include/header.php';  ?>

<?php  include 'views/edit_case_study_gallery.php';  ?>

<?php  include 'include/footer.php';  ?>

