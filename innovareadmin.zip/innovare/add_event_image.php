
<?php  include 'controller/mainClassController.php';  ?>

<?php  include 'controller/authController.php';  ?>

<?php  include 'controller/eventImageController.php';  ?>

<?php  include 'include/header.php';  ?>

<?php  include 'views/add_event_image.php';  ?>

<?php  include 'include/footer.php';  ?>

<?php  include 'xhr/upload_event_doc.php';  ?>
