
<?php  include 'controller/mainClassController.php';  ?>

<?php  include 'controller/authController.php';  ?>

<?php  include 'controller/bannerController.php';  ?>

<?php  include 'include/header.php';  ?>

<?php  include 'views/banner_management.php';  ?>

<?php  include 'include/footer.php';  ?>

<?php //  include 'xhr/edit_slider.php';  ?>
