
<?php  include 'controller/mainClassController.php';  ?>

<?php  include 'controller/authController.php';  ?>

<?php // include 'controller/calenController.php';  ?>

<?php  include 'include/header.php';  ?>

<?php  include 'views/course_calender.php';  ?>

<?php  include 'include/footer.php';  ?>

<?php  include 'xhr/upload_calender.php';  ?>
