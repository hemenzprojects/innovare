<?php 
	
	include 'controller/mainClassController.php';

	include 'controller/logoutController.php';

?>