
<?php  include 'controller/mainClassController.php';  ?>

<?php  include 'controller/authController.php';  ?>

<?php  include 'controller/editAdminController.php';  ?>

<?php  include 'include/header.php';  ?>

<?php  include 'views/edit_admin.php';  ?>

<?php  include 'include/footer.php';  ?>

<?php  include 'xhr/edit_admin.php';  ?>
