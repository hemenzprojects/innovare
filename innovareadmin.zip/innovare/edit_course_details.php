
<?php  include 'controller/mainClassController.php';  ?>

<?php  include 'controller/authController.php';  ?>

<?php  include 'controller/courseController.php';  ?>

<?php  include 'controller/courseImageController.php';  ?>

<?php  include 'include/header.php';  ?>

<?php  include 'views/edit_course_details.php';  ?>

<?php  include 'include/footer.php';  ?>

<?php  include 'xhr/edit_course.php';  ?>
