
<?php  include 'controller/mainClassController.php';  ?>

<?php  include 'controller/authController.php';  ?>

<?php  include 'controller/eventController.php';  ?>

<?php  include 'controller/eventImageController.php';  ?>

<?php  include 'include/header.php';  ?>

<?php  include 'views/edit_event_details.php';  ?>

<?php  include 'include/footer.php';  ?>

<?php  include 'xhr/edit_event.php';  ?>
