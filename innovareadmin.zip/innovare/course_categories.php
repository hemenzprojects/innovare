
<?php  include 'controller/mainClassController.php';  ?>

<?php  include 'controller/authController.php';  ?>

<?php  include 'controller/courseCatController.php';  ?>

<?php  include 'include/header.php';  ?>

<?php  include 'views/course_categories.php';  ?>

<?php  include 'include/footer.php';  ?>

<?php  include 'xhr/course_categories.php';  ?>
