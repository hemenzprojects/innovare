
<?php  include 'controller/mainClassController.php';  ?>

<?php  include 'controller/authController.php';  ?>

<?php  include 'controller/eventCatController.php';  ?>

<?php  include 'include/header.php';  ?>

<?php  include 'views/event_categories.php';  ?>

<?php  include 'include/footer.php';  ?>

<?php  include 'xhr/event_category.php';  ?>
