
<?php  include 'controller/mainClassController.php';  ?>

<?php  include 'controller/authController.php';  ?>

<?php  include 'controller/caseStudyController.php';  ?>

<?php  include 'controller/caseStudyImageController.php';  ?>

<?php  include 'include/header.php';  ?>

<?php  include 'views/edit_case_study_details.php';  ?>

<?php  include 'include/footer.php';  ?>

<?php   include 'xhr/edit_case_study.php';  ?>
